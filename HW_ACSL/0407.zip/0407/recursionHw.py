def powerN(base, n):
    return 0

def noX(str):
    return 0

def parenBit(str):
    return 0

def strDist(str, sub):
    return 0

def groupSum(start, nums, target):
    #start: keep track of current index
    return 0

def groupSum6(start, nums, target):
    return 0